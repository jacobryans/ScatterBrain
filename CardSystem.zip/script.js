
class Deck {
  constructor(array){
    this.cards = array;
  }
}

class Card {
  constructor(object) {
    this.element = object.skeleton.cloneNode(true);
    this.id = object.id;
    this.subject = object.subject;
    this.question = object.question;
    this.answer = object.answer;
    this.color = object.color;
    this.bg = object.bg;
    this.setupCard();
    this.save();
  }
  setupCard() {
    this.element.querySelector('.question').innerText = `${this.question}`;
    this.element.querySelector('.subject').textContent = `${this.subject}`;
    this.element.style.color = `${this.color}`;
    this.element.style.backgroundColor = `${this.bg}`;
    this.element.dataset.card = this.id;
    this.element.classList.toggle('hide');
    document.getElementById('card-box').appendChild(this.element);
    this.element.addEventListener('dblclick', () => {
      this.element.querySelector('div[data-type="subject"]').classList.toggle('hide');
      this.element.querySelector('div[data-type="question"]').classList.toggle('hide');
      this.element.querySelector('.back').classList.toggle('show');
    })
  }
  save() {
    deck.push(this);
  }
}

let cards = [
  {
    'skeleton' : document.querySelector('div[data-card="0"]'),
    'id' : 1,
    'subject' : 'Math',
    'question' : 'What is 2+2?',
    'answer' : 4,
    'color' : 'blue',
    'bg' : 'yellow'
  },
  {
    'skeleton' : document.querySelector('div[data-card="0"]'),
    'id' : 2,
    'subject' : 'Math',
    'question' : 'What is 8/2?',
    'answer' : 4,
    'color' : 'blue',
    'bg' : 'yellow'
  },
  {
    'skeleton' : document.querySelector('div[data-card="0"]'),
    'id' : 3,
    'subject' : 'Math',
    'question' : 'What is 1*4',
    'answer' : 4,
    'color' : 'blue',
    'bg' : 'yellow'
  },
  {
    'skeleton' : document.querySelector('div[data-card="0"]'),
    'id' : 4,
    'subject' : 'Math',
    'question' : 'What is 3+3?',
    'answer' : 6,
    'color' : 'purple',
    'bg' : 'black'
  },
  {
    'skeleton' : document.querySelector('div[data-card="0"]'),
    'id' : 5,
    'subject' : 'Math',
    'question' : 'What is 12/2?',
    'answer' : 6,
    'color' : 'purple',
    'bg' : 'black'
  },
  {
    'skeleton' : document.querySelector('div[data-card="0"]'),
    'id' : 6,
    'subject' : 'Math',
    'question' : 'What is 1*6',
    'answer' : 6,
    'color' : 'purple',
    'bg' : 'black'
  },
  {
    'skeleton' : document.querySelector('div[data-card="0"]'),
    'id' : 7,
    'subject' : 'Math',
    'question' : 'What is 4+4?',
    'answer' : 8,
    'color' : 'white',
    'bg' : 'red'
  },
  {
    'skeleton' : document.querySelector('div[data-card="0"]'),
    'id' : 8,
    'subject' : 'Math',
    'question' : 'What is 16/2?',
    'answer' : 8,
    'color' : 'white',
    'bg' : 'red'
  },
  {
    'skeleton' : document.querySelector('div[data-card="0"]'),
    'id' : 9,
    'subject' : 'Math',
    'question' : 'What is 1*8',
    'answer' : 8,
    'color' : 'white',
    'bg' : 'red'
  },
]

const cardCreate = document.getElementById('card-button');

const deck = [];

cardCreate.addEventListener('click', () => {
  cards.forEach(card => new Card(card));
})



new Deck(deck);